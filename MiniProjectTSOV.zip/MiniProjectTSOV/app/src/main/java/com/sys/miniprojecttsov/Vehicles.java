package com.sys.miniprojecttsov;

public class Vehicles {
    private String Name;
    String checkpt1;
    String checkpt2;
    public Vehicles() {
    }
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getCheckpt1() {
        return checkpt1;
    }

    public void setCheckpt1(String checkpt1) {
        this.checkpt1 = checkpt1;
    }

    public String getCheckpt2() {
        return checkpt2;
    }

    public void setCheckpt2(String checkpt2) {
        this.checkpt2 = checkpt2;
    }


}
